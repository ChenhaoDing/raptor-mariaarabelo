var searchData=
[
  ['year_0',['year',['../structDate.html#a3eeced2ed56bc95d56782b9e738db8ea',1,'Date']]]
];
