var searchData=
[
  ['nextday_0',['NextDay',['../DateTime_8h.html#ac572d2be8b3c04018816ba1a6e75adadaba0b37c4223f9cae64a54e5dd085e3a4',1,'DateTime.h']]]
];
