var searchData=
[
  ['marked_5fstops_0',['marked_stops',['../classRaptor.html#a624fc440483608a7a3c76188405b5cef',1,'Raptor']]],
  ['midnight_1',['MIDNIGHT',['../DateTime_8h.html#a227d770843fd921d89b26b5f043d30ea',1,'DateTime.h']]],
  ['minutes_2',['minutes',['../structTime.html#acdca8b13b904057dfec90b68f3092bc4',1,'Time']]],
  ['month_3',['month',['../structDate.html#a533843e07c6ac8d19fee9b16f5336ba2',1,'Date']]]
];
