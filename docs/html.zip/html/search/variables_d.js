var searchData=
[
  ['weekday_0',['weekday',['../structDate.html#ae330052e5bf47ba22939f8e4a7aac980',1,'Date']]],
  ['weekdays_5fnames_1',['weekdays_names',['../DateTime_8h.html#a0f82494724c4b13c3b6c143ffed4d971',1,'DateTime.h']]]
];
