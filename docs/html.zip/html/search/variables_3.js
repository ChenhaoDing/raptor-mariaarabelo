var searchData=
[
  ['fields_0',['fields',['../classGTFSObject.html#ad6edafcb212b39709c72c8a08f4fb771',1,'GTFSObject']]],
  ['footpaths_1',['footpaths',['../classStop.html#a0e52e37e70d866289d8b96255bb8fdab',1,'Stop']]]
];
