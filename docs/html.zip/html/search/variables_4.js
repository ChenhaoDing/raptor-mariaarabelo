var searchData=
[
  ['hours_0',['hours',['../structTime.html#aa207ff7d820b4c32f22e1474a931b195',1,'Time']]]
];
