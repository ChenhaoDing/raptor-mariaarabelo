var searchData=
[
  ['parent_5fstop_5fid_0',['parent_stop_id',['../structStopInfo.html#af7fee9c9255e5d5762a6a8e334686425',1,'StopInfo']]],
  ['parent_5ftrip_5fid_1',['parent_trip_id',['../structStopInfo.html#ac2eb84268326554a95517111fef4de40',1,'StopInfo']]],
  ['prev_5fmarked_5fstops_2',['prev_marked_stops',['../classRaptor.html#a2021ad49e97be2ffef10c45cb261b3c2',1,'Raptor']]]
];
