var searchData=
[
  ['query_0',['Query',['../structQuery.html',1,'']]],
  ['query_5f_1',['query_',['../classRaptor.html#a8c6b2cf6c9bd4c8aab08ced9f041e125',1,'Raptor']]]
];
