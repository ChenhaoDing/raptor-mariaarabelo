var searchData=
[
  ['active_5fdays_5f_0',['active_days_',['../classTrip.html#a53ba45710929469f86aa894c587b11a3',1,'Trip']]],
  ['agencies_5f_1',['agencies_',['../classParser.html#a4d1c9f79d2e4061cc1ee87c4282d75bb',1,'Parser::agencies_'],['../classRaptor.html#a6336b3d231ea80fb76b3b4f3c9101e7a',1,'Raptor::agencies_']]],
  ['agency_5fname_2',['agency_name',['../structJourneyStep.html#adb29678de0622faf7af2d52174b09722',1,'JourneyStep']]],
  ['arrival_5fday_3',['arrival_day',['../structJourney.html#a71d224aeb5bc5eeecead4a43f1b5d904',1,'Journey']]],
  ['arrival_5fseconds_4',['arrival_seconds',['../structStopInfo.html#a869a91707731d41bb80f062e232bed4b',1,'StopInfo::arrival_seconds'],['../classStopTime.html#aecc828fb1d71cced04c093bf1fcee42e',1,'StopTime::arrival_seconds']]],
  ['arrival_5fsecs_5',['arrival_secs',['../structJourneyStep.html#aa8979f486942492bfeca7baade29abc1',1,'JourneyStep::arrival_secs'],['../structJourney.html#aab034993704df2db85968ea3d103cd42',1,'Journey::arrival_secs']]],
  ['arrivals_5f_6',['arrivals_',['../classRaptor.html#a62ceb0c71652da24478eaf98b43d1a7b',1,'Raptor']]]
];
