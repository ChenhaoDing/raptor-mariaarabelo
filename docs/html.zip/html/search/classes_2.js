var searchData=
[
  ['date_0',['Date',['../structDate.html',1,'']]]
];
