var searchData=
[
  ['date_0',['date',['../structQuery.html#a477d9639c1f9c295023ec8b3becffa21',1,'Query']]],
  ['day_1',['day',['../structDate.html#a5b192adcabf2b2871e3f0b76c1ec1601',1,'Date::day'],['../structStopInfo.html#a5a40e11890e92c11654c1de8897028a6',1,'StopInfo::day'],['../structJourneyStep.html#a5442a2eae255c06e0d8eddb6097da08d',1,'JourneyStep::day']]],
  ['departure_5fday_2',['departure_day',['../structJourney.html#a868493f072bd2919ce8c665db6cd81a6',1,'Journey']]],
  ['departure_5fseconds_3',['departure_seconds',['../classStopTime.html#abf093e6811aa7ebfe95ca211eb4c3a42',1,'StopTime']]],
  ['departure_5fsecs_4',['departure_secs',['../structJourneyStep.html#a6021d1f749fa33e4c029659800a10cfb',1,'JourneyStep::departure_secs'],['../structJourney.html#ad837e6f920df8177034690389a417cf2',1,'Journey::departure_secs']]],
  ['departure_5ftime_5',['departure_time',['../structQuery.html#ab0d94002004a5a293df507bc955c8ce2',1,'Query']]],
  ['dest_5fstop_6',['dest_stop',['../structJourneyStep.html#a5d50dd83db1d4866bdab21c9a2c2642b',1,'JourneyStep']]],
  ['duration_7',['duration',['../structJourneyStep.html#a0b67a08fb70339a81f53c62a67d2cc6e',1,'JourneyStep::duration'],['../structJourney.html#a5f24eae001a345a7fe3b414a3521fb9d',1,'Journey::duration']]]
];
