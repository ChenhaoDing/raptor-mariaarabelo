var searchData=
[
  ['query_0',['Query',['../structQuery.html',1,'']]]
];
